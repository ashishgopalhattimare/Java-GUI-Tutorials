/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collisiondetection;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * This is simple application to draw using java on canvas
 * Use of KeyListener, MouseListener, MouseMotionListener
 * 
 * There are other Listeners as well like WindowListner
 */

/**
 *
 * @author ashishgopalhattimare
 */
public class Animation extends JPanel implements ActionListener, MouseMotionListener, MouseListener, KeyListener
{
    private Timer timer = new Timer(5, this); // GUI version of the sleep method
    // in the above, 'this' belongs to the ActionListener event
    
    public static final int BAR_SIZE = 30;
    
    private ArrayList<Block> arr;
    private Block mouseBlock;
    private Block keyBlock;
    
    JButton button;
    
    private Block a, b;
    
    /**
     * There are different channels in the youtube, which uses different way
     * of implementing this layout
     * You might prefer one over the other
     */
    public Animation()
    {
        timer.start(); // Start the Timer to call ActionListener at every instance
     
        arr = new ArrayList<>();
        
//        arr.add(new Block(0, 10, 1, 1, Color.RED)); // Block RED
        arr.add(new Block(0, 60, 1, 2, Color.BLUE, "Blue")); // Block BLUE
        arr.add(new Block(0, 120, 2, 1, Color.CYAN, "Cyan")); // Block BLUE
        
        arr.add(new Block(0, 30, 0, 0, Color.BLACK, "Black"));
        arr.add(new Block(100, 30, 0, 0, Color.GRAY, "Gray"));
        
        mouseBlock = arr.get(2);
        keyBlock = arr.get(3);
        
        addMouseListener(this);         // Add MouseListener to this canvas (JPanel)
        addMouseMotionListener(this);   // Add MouseMotionListener to this canvas (JPanel)
        addKeyListener(this);           // Add KeyListener to this canvas (JPanel)
        
        setFocusable(true);             // Set focus to this Panel
        
        button = new JButton("BUTTON");
        
        add(this)
    }
    
    /**
     * This functions paints the objects very time
     * even at the time of repaint() call
     * @param g 
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        
        // Before you draw any shape or text, you should set the color first
//        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 600, 400);
        
        // 
        for(int i = 0; i != 2; i++) {
            Block rect = arr.get(i);
            
            g.setColor(rect.color);
            g.fillRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
        }
        
        // This Block is Handled by mouse movement <MouseMotionEvent>
        g.setColor(mouseBlock.color);
        g.fillRect(mouseBlock.getX(), mouseBlock.getY(), mouseBlock.getWidth(), mouseBlock.getHeight());
        
        // This Block is handled by key movement <UP, DOWN, LEFT, RIGHT>
        g.setColor(keyBlock.color);
        g.fillRect(keyBlock.getX(), keyBlock.getY(), keyBlock.getWidth(), keyBlock.getHeight());
        
        boolean noCollide = false;
        for(int i = 0; i < arr.size() && !noCollide; i++) {
            for(int j = 0; j < arr.size() &&!noCollide; j++) {
                if(i == j) continue;
                else {
                    a = arr.get(i); b = arr.get(j);
                    
                    Rectangle rect1 = a.bounds();
                    Rectangle rect2 = b.bounds();
                    
                    // Detect Collision between two objects
                    // There are alternate ways as well
                    // This method only detects the collision!!!
                    if(rect1.intersects(rect2)) {
                        g2d.setColor(Color.RED);
                        String text = "COLLISION DETECTED BETWEEN " + a.getType() + " Block and " + b.getType() + " Block";
                        g2d.drawString(text, 10, 10);
                        
                        noCollide = true;
                    }
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        for(int i = 0; i != 2; i++)
        {
            Block rect = arr.get(i);
            if(rect.getX() < 0 || rect.getX() + rect.getWidth() > 600) {
                rect.changeDirectionVelX();
            }
            if(rect.getY() < 0 || rect.getY() + BAR_SIZE + rect.getHeight()> 400) {
                rect.changeDirectionVelY();
            }
        }
        
        for(int i = 0; i < 2; i++) {
            Block rect = arr.get(i);
            rect.updatePos();
        }
        
        repaint(); // call the paintComponent() method again to draw the updated objects
    }

    @Override
    public void mouseDragged(MouseEvent e) { }

    @Override
    public void mouseMoved(MouseEvent e) {
        mouseBlock.setX(e.getX() - mouseBlock.getWidth()/2);
        mouseBlock.setY(e.getY() - mouseBlock.getHeight()/2);
    }

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println("Mouse Entered the Screen");
    }

    @Override
    public void mouseExited(MouseEvent e) {
        System.out.println("Mouse Exited the Screen");
    }

    @Override
    /**
     * Try to use arrow keys from your keyboard, this may not work
     * as it expects only typed character
     */
    public void keyTyped(KeyEvent e) {}

    @Override
    /**
     * Every Key has its distinct KeyCode
     */
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == 39) { // Go to right
            keyBlock.updateX(1);
        }
        else if(e.getKeyCode() == 39) { // Go to left
            keyBlock.updateX(-1);
        }
        else if(e.getKeyCode() == 38) { // Go to up
            keyBlock.updateY(-1);
        }
        else if(e.getKeyCode() == 40) { // Go to down
            keyBlock.updateY(1);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}
