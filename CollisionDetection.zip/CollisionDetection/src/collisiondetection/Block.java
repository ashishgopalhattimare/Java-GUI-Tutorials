/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collisiondetection;

import java.awt.Color;
import java.awt.Rectangle;

/**
 *
 * @author ashishgopalhattimare
 */
public class Block {
    
    private String type;
    private int x, y;
    private int velX, velY;
    
    public Color color;
    
    private int width, height;
    
    public Block(int x, int y, int velX, int velY, Color color, String type)
    {
        this.x = x;
        this.y = y;
        
        this.velX = velX;
        this.velY = velY;
        
        this.color = color;
        this.type = type;
        
        width = 40; height = 40;
    }
    
    public String getType() { return type; }
    
    public void updatePos() {
        x += velX;
        y += velY;
    }
    
    public void setVelX(int velX) {
        this.velX = velX;
    }
    public void setVelY(int velY) {
        this.velY = velY;
    }
    
    public void changeDirectionVelX() {
        velX = -velX;
    }
    public void changeDirectionVelY() {
        velY = -velY;
    }
    
    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    
    public void updateX(int factor) { x+=factor; }
    public void updateY(int factor) { y+=factor; }
    
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    
    public String toString() {
        return x + "," + y + "," + (x+width) + "," + (y+height);
    }
    
    public Rectangle bounds() {
        return (new Rectangle(x, y, width, height));
    }
}
