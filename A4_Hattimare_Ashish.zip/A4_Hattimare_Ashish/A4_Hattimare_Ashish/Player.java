/*******************************************************************************************************************
  * Player object that is used to store the total and current score of the player and the computer
  *
  * ***************************************************************************************************************/

public class Player
{
  
  /************************
    * Instance Variables
    * ********************/
  
  //Store the total score of the Player
  private int total;
  
  //Store the current score of the Player
  private int current;
  
  //Goal for the Player
  public static int goal;
  
  
  /************************
    * Constructor
    * ********************/
  
  /**
   * Default Constructor
   * Set int total, current, goal of the Player to 0 as default values
   * */
  public Player()
  {
    this.total = 0;
    this.current = 0;
    this.goal = 0;
    
  }//end default Player() constructor
  
  
  /************************
    * Set Methods
    * ********************/
  
  /**
   * Set the total score of the Player
   * @param int total - the total score of the Player
   * @return void
   * */
  public void setTotal(int total)
  {
    this.total = total;
    
  }//end setTotal(int)
  
  /**
   * Set the current score of the Player
   * @param int current - the current score of the Player
   * @return void
   * */
  public void setCurrent(int current)
  {
    this.current = current;
    
  }//end setCurrent(int)
  
  /************************
    * Get Methods
    * ********************/
  
  /**
   * Returns the total score of the Player
   * @param none
   * @return int - total score of the Player
   * */
  public int getTotal()
  {
    return this.total;
  
  }//end getTotal()
  
  /**
   * Returns the current score of the Player
   * @param none
   * @return int - current score of the Player
   * */
  public int getCurrent()
  {
    return this.current;
    
  }//end getCurrent()
  
  @Override
  /**
   * Returns a String representation of the Player object
   * @param none
   * @return String - displays the total and current score of the Player
   * */
  public String toString()
  {
    return ("Total score   : " + this.total + "\nCurrent score : " + this.current + "\n\n");  
  
  }//end toString()
  
}//end class Player