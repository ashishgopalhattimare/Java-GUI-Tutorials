
/*******************************************************************************************************************
  * Assignment  : Pig Dice Game
  * Desciption  : Play a dice game between the player and the computer. The player is required to set the target
  *               for the game and reach it before the computer does. Both the Players are required to roll two
  *               dice simultaneously. If both the dices are 1, the Player who rolled the dice would secure 25
  *               points. If the either one of the die is 1, the Player would secure 0 points. And if the die/dice
  *               are not 1, then the player would secure to get the total of the dice as points plus the already
  *               secured points.
  *               Both the players continue their turns until they get 1 as a die number or they desire* to
  *               stop their turn.
  *               After their turn is over, the Player who played their turn would add the secured points to
  *               their total points.
  *               The Player who manages to get their total score to the target first would win the game.
  *               
  *               * The player can stop his/her roll whenever he/she desires to, while the computer, would be
  *                 given a random number of turns from 1 to 7.
  * 
  * Author : Ashish Gopal Hattimare
  * Date   : 08 May, 2016
  * Course : ICS4U
  * 
  * ***************************************************************************************************************/

//Import all the required java packages
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;

public class A4_Hattimare_Ashish implements ActionListener
{
  
  /*****************************************************************************************************************
    * 
    * JFrame setFrame  - Displays the Set Goal frame
    * JFrame gameFrame - Displays the Dice Game frame
    * 
    * JLabel lblSet     - It displays the text of the target score
    * JTextField txtSet - It stores the target value from the Player
    * JButton btnSet    - Allow the Player to set the target score and start the Dice Game
    * 
    * JPanel setPanel     - The holds the JPanels in the Set Goal Frame
    * JPanel set_lblPanel - It holds the lblSet in the Set Goal frame
    * JPanel set_txtPanel - It holds the txtSet in the Set Goal frame
    * JPanel set_btnPanel - It holds the btnSet in the Set Goal frame
    * 
    * JPanel centerPanel - It holds the JPanels for the Dice game
    * 
    * ImageIcon imgPlayer - Image of the player
    * ImageIcon imgComp   - Image of the computer
    * 
    * JLabel lbl_leftImage  - It holds the image of the player
    * JLabel lbl_rightImage - It holds the image of the computer
    * 
    * JPanel playerPanel - Panel that displays the image of the player on the left side of the dice game
    * JPanel compPanel   - Panel that displays the image of the computer on the right side of the dice
    *                      game
    * 
    * JPanel gamePanel - It holds the JPanels for the dice game frame
    * 
    * JLabel lblTarget - Display the target score to the Players
    * JLabel lbl_playerTitle - Display the title of the player's total
    * JLabel lbl_compTitle - Display the title of the computer's total
    * JLabel lbl_diceTotal - Display the total of the dice rolled by the Players
    * JLabel lbl_currTotal - Display the current score of the Players
    * JLabel lbl_playerScore - Display the total score of the player
    * JLabel lbl_compScore - Display the total score of the computer
    * 
    * JButton btnRoll   - To roll the dice for the Player
    * JButton btnStop   - To end the player's turn to roll the dice
    * JButton btnSwitch - To switch the Player's turn to roll the dice
    * 
    * JPanel[] dicePanel - An array of similar JPanels that are used to display the dice rolled by the
    *                      Player
    * 
    * JPanel game_goalPanel      - It holds the display of the goal label
    * JPanel game_titlePanel     - It holds the display of the title name of both the players
    * JPanel game_scorepanel     - It holds the total score of both the players
    * JPanel game_dicePanel      - It holds the image of both the dice
    * JPanel game_diceTotalPanel - It holds the display of the diceTotal label
    * JPanel game_currPanel      - It holds the display of the currentTotal label of the Player
    * JPanel game_btnPanel       - It holds the "Roll", "Stop", "Switch" buttons
    * 
    * Dice leftDice  - This instance Dice class draws the image of the left dice rolled and displays it
    *                  on the left side of the dicePanel
    * Dice rightDice - This instance Dice class draws the image of the right dice rolled and displays it
    *                  on the right side of the dicePanel
    * 
    * Player player   - This instance Player class stores all the information related to the player
    *                   i.e. total score, current score, and goal score
    * Player computer - This instance Player class stores all the information related to the computer
    *                   i.e. total score, current score, and goal score
    *
    * int dice1 - It stores the number rolled by the left dice
    * int dice2 - it stores the number rolled by the right dice
    * int diceTotal - It stores the total of the two dices rolled by the Player
    * int compTurns - It stores the number of how many times the computer would roll the dice
    *
    * boolean playerTurn - Check whether the player has to roll the dice or the computer.
    *
    * String winMessage - It stores the String of whether player won the game or the computer
    * 
    * ArrayList<String> roundDetail - This arrayList stores all the required information about the player's
    *                                 and computer's every move
    * 
    * *************************************************************************************************************/
  
  JFrame setFrame, gameFrame;
  
  
  /*************************
    * Set Frame Components
    * *********************/
  
  JLabel lblSet;
  JButton btnSet;
  JTextField txtSet;
  
  JPanel setPanel, set_lblPanel, set_txtPanel, set_btnPanel;
  
  
  /*************************
    * Game Frame Components
    * *********************/
  
  JPanel gamePanel;
  
  //JPanels for the Dice Game
  JPanel centerPanel;
  
  //Left and Right side ImagePanel
  JPanel playerPanel, compPanel;
  JLabel lbl_leftImage, lbl_rightImage;
  
  //Images of the player and the computer
  ImageIcon imgPlayer, imgComp;
  
  public JLabel lblTarget, lbl_playerTitle, lbl_compTitle, lbl_diceTotal, lbl_currTotal,
                lbl_playerScore, lbl_compScore;
  
  //JButtons for the dice Game
  JButton btnRoll, btnStop, btnSwitch;
  
  //JPanels that holds the image of the two dices rolled
  JPanel[] dicePanel;
  
  //JPanels for all the components of the dice Game
  JPanel game_goalPanel, game_btnPanel, game_dicePanel, game_titlePanel, game_diceTotalPanel, game_currPanel,
         game_scorePanel; 
  
  public static int diceTotal;
  int dice1, dice2;
  
  //To check whether its player turn or computer's to roll the dice
  boolean playerTurn;
  
  //Check whether the player score is added to the total score or not
  boolean scorePlayer;
  
  //Dice Class that handles the dices
  Dice leftDice, rightDice;
  
  //Player Class that handles the players information
  Player player, computer;
  
  //Maximum number of computer could roll
  int compTurns;
  
  //Displays the winning message on the screen
  String winMessage;
  
  //Stores the information about computer's and player's every move
  ArrayList<String> roundDetail;
  
  //Write the detailed information about the game in the pig.txt file
  FileWriter fw;
  PrintWriter outFile;
  Scanner scanFile;
  String fileName = "pig.txt";
  
  Font font, scoreFont;
  
  /**
   * Default Constructor
   * Set the components of the game
   * */
  public A4_Hattimare_Ashish()
  {
    
    //Set title to the JFrames
    setFrame = new JFrame("Pig Dice Game - Set Goal");
    gameFrame = new JFrame("Pig Dice Game");
    
    //Start the dice Game with the player's turn
    playerTurn = true;
    
    font = new Font("Century Gothic", Font.BOLD, 13);
    scoreFont = new Font("Century Gothic", Font.BOLD | Font.ITALIC, 20);
    
    //The player score is not registered in the total
    scorePlayer = false;
    
    roundDetail = new ArrayList<String>();
    
    //Create player and computer instance classes
    player = new Player();
    computer = new Player();
    
    //Create leftDice and rightDice instance classes 
    leftDice = new Dice();
    rightDice = new Dice();
    
    //Set the setPanel
    setPanel = new JPanel();
    setPanel.setLayout(new BoxLayout(setPanel, BoxLayout.Y_AXIS));
    setPanel.setBorder(BorderFactory.createEmptyBorder(35, 20, 20, 20));
    setPanel.setPreferredSize(new Dimension(377, 150));
    
    //Create JPanels for the label, text, and the button
    set_lblPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    set_txtPanel = new JPanel();
    set_btnPanel = new JPanel(new FlowLayout());
    
    //Create the label text, textField, and the button
    lblSet = new JLabel("Enter the target value (greater than or equal to 6) :", JLabel.LEFT);
    lblSet.setFont(font);
    
    txtSet = new JTextField(28);
    txtSet.setFont(font);
    
    btnSet = new JButton("ENTER");
    btnSet.setFont(font);
    
    //Add ActionListener to the setPanel button
    btnSet.addActionListener(this);
    
    //Add the label text, textField and the button to their respective JPanels
    set_lblPanel.add(lblSet);
    set_txtPanel.add(txtSet);
    set_btnPanel.add(btnSet);
    
    //Add add the subPanels of the set Frame to the main Panel of the setFrame
    setPanel.add(set_lblPanel);
    setPanel.add(set_txtPanel);
    setPanel.add(set_btnPanel);
    
    //Set the game Panel for the dice game
    gamePanel = new JPanel();
    gamePanel.setLayout(new BoxLayout(gamePanel, BoxLayout.X_AXIS));
    gamePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createRaisedBevelBorder(),
                                                           BorderFactory.createLoweredBevelBorder()));
    gamePanel.setPreferredSize(new Dimension(600, 350));
    
    //Set Panels to display the image of the player and the computer
    playerPanel = new JPanel();
    compPanel = new JPanel();
    
    //Set labels to hold the images of the Players
    lbl_leftImage = new JLabel();
    lbl_rightImage = new JLabel();
    
    //Import images and add the to the labels
    setImages("Player.png", "Computer.png");
    
    //Add the image labels to their respective panels
    playerPanel.add(lbl_leftImage);
    compPanel.add(lbl_rightImage);
    
    //Set the centerPanel for the dice Game
    centerPanel = new JPanel();
    centerPanel.setBorder(BorderFactory.createEmptyBorder(18, 5, 5, 0));
    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
    centerPanel.setPreferredSize(new Dimension(380, 350));
    
    //Set all the required the required JLabels for the dice Game
    
    //Goal Score
    lblTarget = new JLabel("The Goal is " + Player.goal, JLabel.CENTER);
    lblTarget.setFont(font);
    
    //Player total title
    lbl_playerTitle = new JLabel("   Player's Total", JLabel.CENTER);
    lbl_playerTitle.setFont(font);
    
    //Player's total score
    lbl_playerScore = new JLabel("10", JLabel.CENTER);
    lbl_playerScore.setFont(scoreFont);
    
    //Computer total title
    lbl_compTitle = new JLabel(" Computer's Total", JLabel.CENTER);
    lbl_compTitle.setFont(font);
    
    //Computer's total score
    lbl_compScore = new JLabel("10", JLabel.CENTER);
    lbl_compScore.setFont(scoreFont);
    
    //Dice total
    lbl_diceTotal = new JLabel("Dice Total :  " + diceTotal, JLabel.CENTER);
    lbl_diceTotal.setFont(font);
    
    //The Current score of the player or the computer
    lbl_currTotal = new JLabel("Player's Current Score :  " + player.getCurrent(), JLabel.CENTER);
    lbl_currTotal.setForeground(Color.RED);
    lbl_currTotal.setFont(font);
    
    //JButtons for the dice Game
    btnRoll = new JButton("ROLL");
    btnRoll.setFont(font);
    
    btnStop = new JButton("STOP");
    btnStop.setFont(font);
    
    btnSwitch = new JButton("SWITCH PLAYER");
    btnSwitch.setFont(font);
    
    //Disable the buttons that are not required
    buttonManipulate(true, true, false);
    
    //Add ActionListener to dice Game buttons
    btnRoll.addActionListener(this);
    btnStop.addActionListener(this);
    btnSwitch.addActionListener(this);
    
    //Create two dicePanels for the left and right dice
    dicePanel = new JPanel[2];
    
    //Create two identical dicePanels that holds the dice images
    for(int x = 0; x < dicePanel.length; x++)
    {
      dicePanel[x] = new JPanel(new BorderLayout());
      dicePanel[x].setPreferredSize(new Dimension(100, 100));
      dicePanel[x].setBorder(BorderFactory.createCompoundBorder(BorderFactory.createRaisedBevelBorder(),
                                                                BorderFactory.createLoweredBevelBorder()));
      
    }//end for
    
    //Add the Dice images to the dicePanels
    dicePanel[0].add(leftDice);
    dicePanel[1].add(rightDice);
    
    //Create a JPanel that holds the target score for both the Player and the Computer
    game_goalPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_goalPanel.add(lblTarget);
    game_goalPanel.setPreferredSize(new Dimension(8, 15));
    
    //Create a JPanel that displays the title of the Player and the Computer
    game_titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_titlePanel.add(lbl_playerTitle);
    game_titlePanel.add(Box.createHorizontalStrut(31));
    game_titlePanel.add(lbl_compTitle);
    game_titlePanel.setPreferredSize(new Dimension(8, 10));
    
    //Create a JPanel that displays the total score of the player and the computer
    game_scorePanel = new JPanel(new GridLayout(1, 2));
    game_scorePanel.setPreferredSize(new Dimension(8, 10));
    
    game_scorePanel.add(lbl_playerScore);
    game_scorePanel.add(lbl_compScore);
    
    //Create a JPanel that displays the dice rolled by the Player or the Computer
    game_dicePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_dicePanel.add(dicePanel[0]);
    game_dicePanel.add(Box.createHorizontalStrut(36));
    game_dicePanel.add(dicePanel[1]);
    
    //Create a JPanel that displays the total of the dice rolled
    game_diceTotalPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_diceTotalPanel.add(lbl_diceTotal);
    
    //Create a JPanel that displays the current score of the Player or the Computer
    game_currPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_currPanel.add(lbl_currTotal);
    
    //Create a JPanel that holds that buttons for the dice Game
    game_btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    game_btnPanel.add(btnRoll);
    game_btnPanel.add(Box.createHorizontalStrut(5));
    game_btnPanel.add(btnStop);
    game_btnPanel.add(Box.createHorizontalStrut(5));
    game_btnPanel.add(btnSwitch);
    
    //Add all the JPanel on to the centerPanel of the dice Game
    centerPanel.add(game_goalPanel);
    centerPanel.add(game_titlePanel);
    centerPanel.add(game_scorePanel);
    centerPanel.add(game_dicePanel);
    centerPanel.add(game_diceTotalPanel);
    centerPanel.add(game_currPanel);
    centerPanel.add(game_btnPanel);
   
    //Add the centerPanel and players image panels to the gamePanel
    gamePanel.add(playerPanel);
    gamePanel.add(centerPanel);
    gamePanel.add(compPanel);
    
    //Add the setPanel to the setFrame
    setFrame.add(setPanel);
    
    //Add the gamePanel to the gameFrame
    gameFrame.add(gamePanel);
    
    //Display the setFrame as default
    frameDisplay(setFrame, true);
    frameDisplay(gameFrame, false);
    
  }//end A4_Hattimare_Ashish() constructor
  
  /**
   * Method Name : setImages
   * Purpose : Change and display the image of the Players
   * @param String player - Store the name of the player image
   * @param String computer - Store the name of the computer image
   * @return - Display the image of the Players
   * */
  public void setImages(String player, String computer)
  {
    //Attempt to add the images to their labels
    try
    {
      //Import the images of the Players from the directory
      imgPlayer = new ImageIcon(player);
      imgComp = new ImageIcon(computer);
      
      //Change the size of the images
      imgPlayer = new ImageIcon(imgPlayer.getImage().getScaledInstance(135, 320, java.awt.Image.SCALE_SMOOTH));
      imgComp = new ImageIcon(imgComp.getImage().getScaledInstance(135, 320, java.awt.Image.SCALE_SMOOTH));
      
      //Clear the labels
      lbl_leftImage.setIcon(null);
      lbl_rightImage.setIcon(null);
      
      //Add the images to the their labels
      lbl_leftImage.setIcon(imgPlayer);
      lbl_rightImage.setIcon(imgComp);
    }
    
    catch(Exception e)
    {
      System.out.println("Image import error");
    }//end try/catch
    
  }//end setImages(String, String)
  
  /**
   * Method Name : frameDisplay
   * Purpose : Set the JFrame for the setting and game
   * @param JFrame f - The JFrame for the setting or the dice Game
   * @param Boolean visible - Whether the JFrame should be displayed or not
   * @return void
   * */
  public static void frameDisplay(JFrame f, boolean visible)
  {
    
    f.pack();
    f.setResizable(false);
    f.setLocationRelativeTo(null);
    f.setVisible(visible);
    
  }//end frameDisplay(Frame, boolean)
  
  /**
   * Purpose : Perform an action when a button is clicked
   * */
  public void actionPerformed(ActionEvent e)
  {
    
    //When the "Enter" button is clicked in the Set game
    if(e.getSource() == btnSet)
    {
      
      //Attemp to get the integer value from the JTextField txtSet
      try
      {
        //Get the Integer value from the txtSet
        Player.goal = Integer.valueOf(txtSet.getText());
        
        //Start the game, if the value is greater than or equal to 6
        if(Player.goal >= 6)
        {
          //Display the gameFrame to start the dice Game
          gameFrame.setVisible(true);
          setFrame.setVisible(false);
          
          //Add the goal detail to the roundDetail arrayList
          roundDetail.add("Goal = " + Player.goal);
          roundDetail.add(" ");
          roundDetail.add("Player's Turn");
          roundDetail.add(" ");
          
          //Update all the Dice Game Labels
          updateLabel();
          
        }//end if
      }
      
      catch(Exception error)
      {
        lblSet.setText("Please enter an integer :");
        txtSet.setText(null);
        
      }//end try and catch(Exception)
    }
    
    //When the "Roll" button is clicked in the dice Game
    else if(e.getSource() == btnRoll)
    {
      
      //Roll a random dice number from 1 to 6
      dice1 = (int)(Math.random()*6) + 1;
      dice2 = (int)(Math.random()*6) + 1;
      
      //Calculate the total of the dice rolled and assign it to the diceTotal
      diceTotal = dice1 + dice2;
      
      //Set the random rolled number to the dice
      leftDice.setDie(dice1);
      rightDice.setDie(dice2);
      
      //Repaint the dice
      leftDice.repaint();
      rightDice.repaint();
      
      //Make dice visible to the Players
      leftDice.setDisplay(true);
      rightDice.setDisplay(true);
      
      //Calculate the current score if the player has rolled the dice
      if(playerTurn)
      {
        player.setCurrent(playerCurrent(dice1, dice2, playerTurn));
        currentScore(playerTurn);
        
        //Add player's dice rolled and current score information in the recordDetail ArrayList
        roundDetail.add("Player's Roll");
        roundDetail.add("Dice : " + dice1 + ", " + dice2);
        roundDetail.add("Score : " + player.getCurrent());
        roundDetail.add(" ");
        
      }
      
      //Calculate the current score if the computer has rolled the dice
      else
      {
        computer.setCurrent(playerCurrent(dice1, dice2, playerTurn));
        currentScore(playerTurn);
        
        //Add computer's dice rolled and current score information in the recordDetail ArrayList
        roundDetail.add("Computer's Roll");
        roundDetail.add("Dice : " + dice1 + ", " + dice2);
        roundDetail.add("Score : " + computer.getCurrent());
        roundDetail.add(" ");
        
        compTurns--;
      }
      
      updateLabel();
      
      //If the computer has reached its max turns
      if(!playerTurn && compTurns == 0)
      {
        buttonManipulate(false, false, true);
      }
      
    }
    
    //When the "Stop" button is clicked in the dice Game
    else if(e.getSource() == btnStop)
    {
      //Add the player's current score to the total score
      player.setTotal(player.getTotal() + player.getCurrent());
      
      buttonManipulate(false, false, true);
      
      scorePlayer = true;
      
      //Display the player's current score
      currentScore(playerTurn);
    }
    
    //When the "Switch" button is clicked in the dice Game
    else
    {
      //If the button is pressed by the player
      if(playerTurn)
      {
        //Add the player's current score to the total score if not added
        if(!scorePlayer)
        {
          player.setTotal(player.getTotal() + player.getCurrent());
        }
        
        //Switch from player to computer
        buttonManipulate(true, false, false);
        
        //Get the maximum number of random turn for the computer
        compTurns = (int)(Math.random() * 7) + 1;
        
        //Change the player's score entered to false for the next check
        scorePlayer = false;
        
        //Add player total score in the roundDetail ArrayList
        roundDetail.add("End Player's Turn");
        roundDetail.add("Player's Total : " + player.getTotal());
        roundDetail.add(" ");
        
      }
      
      //If the button is pressed by the computer
      else
      {
        //Update the computer's total score
        computer.setTotal(computer.getTotal() + computer.getCurrent());
        
        //Switch from computer to player
        buttonManipulate(true, true, false);
        
        roundDetail.add("End Computer's Turn");
        roundDetail.add("Computer's Total : " + computer.getTotal());
        roundDetail.add(" ");
        
      }//end if
      
      //Set the current of both the Players to 0
      player.setCurrent(0);
      computer.setCurrent(0);
      
      //Update the Labels in the dice game
      updateLabel();
      
      //Switch turn
      playerTurn = !playerTurn;
      
      //Display the current score label in the dice game
      currentScore(playerTurn);
      
      //Display which Player has won the dice game
      if(goalReach())
      {
        lbl_currTotal.setForeground(Color.GREEN);
        lbl_currTotal.setText(winMessage);
        
        //Disable all the buttons when the game is over
        buttonManipulate(false, false, false);
        
        roundDetail.add(winMessage);
        
        //Add the information in the file - pig.txt
        writeFile(roundDetail, fileName);
        
      }//end if
      
      //If no player has won the game, then continue the game
      else
      {
        if(playerTurn)
        {
          //Add total number of computer can roll the dice to the roundDetail ArrayList
          roundDetail.add("Computer's Turn");
          roundDetail.add(" ");
          roundDetail.add("Computer gets " + compTurns + " rolls");
          roundDetail.add(" ");
          
        }//end if
      }//end if
      
    }//end if
    
  }
  
  /**
   * Method Name : writeFile
   * Purpose : Write the game rounds in the file
   * @param ArrayList<String> array - It contains all the rounds information
   * @return void - Create a file with dice Game information
   * */
  public void writeFile(ArrayList<String> array, String file)
  {
    
    //Attempt to create file and add the information of the game in it
    try
    {
      fw = new FileWriter(file);
      outFile = new PrintWriter(fw);
      
      //Read the arrayList
      for(String info : array)
      {
        //Add the elements of the array to the file created
        outFile.println(info);
      }
      
      //close the file
      outFile.close();
    }
    
    //Error if the file is not created
    catch(IOException io)
    {
      System.out.println("Error : " + io);
    }
    
  }//end writeFile(ArrayList<String>)
  
  /**
   * Method Name : currentScore
   * Purpose : Update the current score of the current Player
   * @param boolean playerTurn - Decides which Player's turn is it
   * @return void - Display the current score
   * */
  public void currentScore(boolean playerTurn)
  {
    
    //If the current Player is the player
    if(playerTurn)
    {
      lbl_currTotal.setForeground(Color.RED);
      lbl_currTotal.setText("Player's Current Score :  " + player.getCurrent());
    }
    
    //If the current Player is the computer
    else
    {
      lbl_currTotal.setForeground(Color.BLUE);
      lbl_currTotal.setText("Computer's Current Score :  " + computer.getCurrent());    
    }
    
  }//end currentScore(boolean)
  
  /**
   * Method Name : playerCurrent
   * Purpose : Calculate the current score of the Player
   * @param int dice1 - the number rolled by the leftDice
   * @param int dice2 - the number rolled by the rightDice
   * @param boolean playerTurn - Decides which Player's turn is it
   * @return int - returns the current score of the Player
   * */
  public int playerCurrent(int dice1, int dice2, boolean playerTurn)
  {
    
    //If both the dice has rolled more than 1
    if(!(dice1 == 1 || dice2 == 1))
    {
      //If the dice were rolled by the player
      if(playerTurn)
      {
        return (player.getCurrent() + dice1 + dice2);
      }
      
      //If the dice were rolled by the computer
      else
      {
        return (computer.getCurrent() + dice1 + dice2);
      }
    }
    
    //If the dice1 and dice2 are rolled to 1, get current score of the Player to 25
    else if(dice1 == 1 && dice2 == 1)
    {
      buttonManipulate(false, false, true);
      return 25;
    }
    
    //If the dice1 is 0 or the dice2 is 0, return 0 as current score
    buttonManipulate(false, false, true);
    
    return 0;
    
  }//end playerCurrent(int, int, boolean)
  
  /**
   * Method Name : goalReach
   * Purpose : Checks whether the Player has reached the goal or not
   * @return boolean - is the game Won or not by anyone
   * */
  public boolean goalReach()
  {
    
    //If player has reached the goal score
    if(player.getTotal() >= Player.goal)
    {
      winMessage = "You Win! You've Reached the Goal First!";
      
      //Change the mood of the Players
      setImages("Player_Win.png", "Computer_Lose.png");
      
      return true;
    }
    
    //If the computer has reached the goal score
    else if(computer.getTotal() >= Player.goal)
    {
      winMessage = "You Lose! The Comp. Reached the Goal First!";
      
      //Change the mood of the Players
      setImages("Player_Lose.png", "Computer_Win.png");
      
      return true;
    }//end if
    
    return false;
    
  }//end goalReach()
  
  /**
   * Method Name : buttonManipulate
   * Purpose : Enable and Disable the dice Game buttons
   * @param boolean roll - whether the "Roll" buttons should be enabled or disabled
   * @param boolean stop - whether the "Stop" buttons should be enabled or disabled
   * @param boolean change - whether the "Switch Player" buttons should be enabled or disabled
   * @return void
   * */
  public void buttonManipulate(boolean roll, boolean stop, boolean change)
  {
    
    btnRoll.setEnabled(roll);
    btnStop.setEnabled(stop);
    btnSwitch.setEnabled(change);
    
  }//end buttonManipulate(boolean, boolean, boolean)
  
  /**
   * Method Name : updateLabel
   * @param none
   * @return void - update all the dice game labels
   * */
  public void updateLabel()
  {
    lblTarget.setText("The Goal is " + Player.goal);
    lbl_playerScore.setText("" + player.getTotal());
    lbl_compScore.setText("" + computer.getTotal());
    lbl_diceTotal.setText("Dice Total :  " + diceTotal);
    
  }//end updateLabel()
  
  //main
  public static void main(String[] args)
  {
    new A4_Hattimare_Ashish();
    
  }//end main
  
}//end class A4_Hattimare_Ashish