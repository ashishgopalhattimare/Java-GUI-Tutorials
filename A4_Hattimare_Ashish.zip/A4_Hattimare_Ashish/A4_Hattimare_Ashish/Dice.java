/*******************************************************************************************************************
  * Dice object that is used to store the dice number and display the dice image
  * 
  * ***************************************************************************************************************/

//Import required packages
import java.awt.*;
import javax.swing.*;

public class Dice extends JPanel
{
  
  /************************
    * Instance Variables
    * ********************/
  
  //Store the rolled number
  private int die;
  
  //Whether the dice should be visible or not
  private boolean displayDice;
  
  //index position of the dots in the dots String
  private int index;
  
  /************************
    * Class Variables
    * ********************/
  
  //Array of all the possible positioning of dots on the dice face
  public static String[] diceDots = {"", "....X....", "X.......X", "X...X...X", "X.X...X.X", "X.X.X.X.X", "XXX...XXX"};
  
  
  /************************
    * Constuctor
    * ********************/
  
  /**
   * Default Constructor
   * Construct the display of the dice to false as default
   * @param none
   * */
  public Dice()
  {
    this.displayDice = false;
    
  }//end defaut Dice() constructor
  
  
  /************************
    * Set Methods
    * ********************/
  
  /**
   * Set the number rolled by the dice to die variable
   * @param int roll - the number of the dice
   * @return void
   * */
  public void setDie(int roll)
  {
    this.die = roll;
    
  }//end setDie(int)
  
  /**
   * Display the dice
   * @param boolean visible - whether the dice should be visible or not
   * @return void
   * */
  public void setDisplay(boolean visible)
  {
    this.displayDice = visible;
    
  }//end setDisplay(boolean)
  
  @Override
  /**
   * Draw the dots on the Dice
   * return void
   * */
    public void paintComponent(Graphics g)
  {
    super.paintComponent(g);
    
    //Set background color to white
    g.setColor(Color.WHITE);
    g.fillRect(0, 0, getWidth(), getHeight());
    
    //If the dice image is set to visible
    if(displayDice)
    {
      
      //Draw the dots on the dice
      index = 0;
      for(int row = 0; row < 3; row++)
      {
        for(int col = 0; col < 3; col++)
        {
          //Draw the dot
          if((diceDots[die].charAt(index)) == 'X')
          {
            drawCircle(g, 27 * row + 5, 27 * col + 5, 23);
          }//end if
          
          index++;
        }//end for
      }//end for 
    
    }//end if
    
  }//end paintComponent(Graphics)
  
  
  /************************
    * Instance Methods
    * ********************/
  
  /**
   * Draw the dots on the die
   * @param Graphics g - Allows to draw on the panel
   * @param int row - The x coordinate of the dot on the die
   * @param int col - The y coordinate of the dot on the die
   * @param int radius - The width and height of the dot
   * @return - displays the dot on the die
   * */
  public void drawCircle(Graphics g, int row, int col, int radius)
  {
    g.setColor(Color.BLACK);
    g.fillOval(row, col, radius, radius);
    g.drawOval(row, col, radius, radius);
    
  }//end drawCircle(Graphics, int, int, int)
  
  @Override
  /**
   * Method Name : toString
   * @param none
   * @return String - empty string
   * */
    public String toString()
  {
    return ""; 
  }

}//end class Dice